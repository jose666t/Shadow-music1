export interface AudiusTrack {
  id: string;
  title: string;
  artist: string;
  artwork: string;
  streamUrl: string;
  duration: number;
}